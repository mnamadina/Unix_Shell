package cs131.pa1.filter.sequential;
import java.util.LinkedList; 

/**
 * The WordCount filter (wc) class extends SequentialFilter class and is supposed to implement a functionality
 * of counting the number of lines, words and characters, and sending the overall output to the output queue as a string.
 *  
 * @author Madina Nasriddinova
 *
 */
public class WordCountFilter extends SequentialFilter {
	
	/**
	 * three global variables for the counts of lines, words and characters.
	 */
	private int lineCount = 0;
    private int wordCount = 0;
    private int charCount = 0;
    
    /**
     * this method iterates through the input queue and counts lines, words, and characters.
     * it then concatenates everything into a string and sends it to the output.
     */
    @Override
    public void process() {
    	if (output == null) {
            output = new LinkedList<>();
        }
    	// iterate through the input queue and count everything
        while (!input.isEmpty()) {
        	String line = input.poll();
            lineCount++;
            wordCount += line.split("\\s+").length; // Split by one or more spaces
            charCount += line.length();
            	}
            String result = lineCount + " " + wordCount + " " + charCount;
            // Format the output as "lineCount wordCount charCount"        
            output.add(result);
    }

	@Override
	protected String processLine(String line) {
		return null;
	}
	
}
