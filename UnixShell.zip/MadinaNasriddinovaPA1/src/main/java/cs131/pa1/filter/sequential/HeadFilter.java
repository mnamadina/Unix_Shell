package cs131.pa1.filter.sequential;
import java.util.LinkedList; 

/**
 * The Head filter class extends SequentialFilter class and is supposed to implement a functionality
 * of returning the first n lines from the piped input. The number of lines is passed
 * as a parameter to the constructor.
 *  
 * @author Madina Nasriddinova
 *
 */
public class HeadFilter extends SequentialFilter {
	
	/**
	 * the global variable that will hold the parsed value of the value n
	 */
	private int number;
	
	/**
	 * The basic constructor that accepts the string value of the number of lines that need to be returned from the input.
	 * I then parse it into int variable. Also create the output queue.
	 * @param n - the string value of the number of lines that need to be evaluated
	 */
	public HeadFilter(String n) {
		this.number = Integer.parseInt(n);
		if (this.output == null) {
			this.output = new LinkedList<>();
		}
	}
	
	/**
	 * the method goes through the input queue and returns up to n lines as needed (into the output queue).
	 */
	@Override
	public void process() {
		// Process input lines up to the specified number
        int linesProcessed = 0;
        
        while (!this.input.isEmpty() && linesProcessed < number) {
            String line = this.input.poll();
            if (line != null) {
                this.output.add(line);
                linesProcessed++;
            }
        }
	}

	@Override
	protected String processLine(String line) {
		return null;
	}
	
}
