package cs131.pa1.filter.sequential;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;

/**
 * The Uniq filter class extends SequentialFilter class and is supposed to implement a functionality
 * of returning unique lines that don't have any other duplicated in the input.
 *  
 * @author Madina Nasriddinova
 *
 */
public class UniqFilter extends SequentialFilter {
	
	/**
	 * the global variable for the lines that have been processed in the input queue.
	 */
	private Set<String> seenLines = new HashSet<>();
	
	/**
	 * this method evaluates lines from the input queue, and adds them to the output queue if they are unique.
	 */
	@Override
    public void process() {
        if (this.output == null) {
            this.output = new LinkedList<>();
        }
        while (!this.input.isEmpty()) {
            String line = this.input.poll();
            line = processLine(line);
            if (line != null) {
                this.output.add(line);
            }
        }
    }
    
	/**
	 * this method checks whether the set of the already processed lines contains a new line that has been read from the 
	 * input queue. if the line is not in the set, I add it there, and return line. If the line is already in the set, it means there has been
	 * a dupe, so I return null.
	 */
    @Override
    protected String processLine(String line) {
        if (!seenLines.contains(line)) {
            seenLines.add(line);
            return line; // Line is unique; return it for output
        }
        return null; // Line is a duplicate; skip it
    }
	
}
