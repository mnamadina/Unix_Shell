package cs131.pa1.filter.sequential;
import java.util.LinkedList; 

/**
 * The Tail filter class extends SequentialFilter class and is supposed to implement a functionality
 * of returning the last n lines from the piped input. The number of lines is passed
 * as a parameter to the constructor.
 *  
 * @author Madina Nasriddinova
 *
 */
public class TailFilter extends SequentialFilter {
	
	/**
	 * the global variable that will hold the parsed value of the value n
	 */
	private int number;
	
	/**
	 * The basic constructor that accepts the string value of the number of lines that need to be returned from the input.
	 * I then parse it into int variable. Also create the output queue.
	 * @param n - the string value of the number of lines that need to be evaluated
	 */
	public TailFilter(String n) {
		this.number = Integer.parseInt(n);
		if (this.output == null) {
			this.output = new LinkedList<>();
		}
	}
	
	/**
	 * the method goes through the input queue and returns up to n lines from down to up as needed (into the output queue).
	 */
	@Override
    public void process() {
        LinkedList<String> allLines = new LinkedList<>();
        while (!this.input.isEmpty()) {
            String line = this.input.poll();
            if (line != null) {
                allLines.add(line);
            }
        }
        
        // add the last 'n' lines to output
        int startIndex = Math.max(0, allLines.size() - number);
        for (int i = startIndex; i < allLines.size(); i++) {
            this.output.add(allLines.get(i));
        }
    }
	
	
	@Override
	protected String processLine(String line) {
		return null;
	}


	
}

