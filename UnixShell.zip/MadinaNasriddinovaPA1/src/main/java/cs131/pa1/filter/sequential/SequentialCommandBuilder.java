package cs131.pa1.filter.sequential;
import java.util.List; 


import cs131.pa1.filter.Message;
import java.util.ArrayList;

/**
 * This class manages the parsing and execution of a command. It splits the raw
 * input into separated subcommands, creates subcommand filters, and links them
 * into a list.
 * 
 * @author Madina Nasriddinova
 *
 */
public class SequentialCommandBuilder {
	
	private static List<String> subcommands;
	
	/**
	 * Creates and returns a list of filters from the specified command
	 * 
	 * @param command the command to create filters from
	 * @return the list of filters that are piped or are singular ones
	 */
	public static List<SequentialFilter> createFiltersFromCommand(String command) {
		
		List<SequentialFilter> filters = new ArrayList<>();
      
        subcommands = splitCommand(command);
        
        for (String subcommand : subcommands) {
        	// and add the SequentialFilter type to filters
        	SequentialFilter value = constructFilterFromSubCommand(subcommand);
        	// I set the value of the filter to be null as an object if the command passed was not identified.
        	if (value != null) {
        		filters.add(value);
        	}
        	else {
        		return null;
        	}
        }   
        return filters;
	}
	
	/**
	 * This method takes in the unsplit rawn String command and splits the command by "|" and ">" characters,
	 * putting the subcommands and parameters together into the list
	 * @param command - the command that is passed from the user input
	 * @return - a list of subcommands together with their parameters (if they are there)
	 */
	private static List<String> splitCommand(String command){
		List<String> subparts = new ArrayList<>();
		String currentPart = "";
		int i = 0;
		
		// iterate through the command and start splitting
		while (i < command.length()) {
            if (command.charAt(i) == '|') {
                if (!currentPart.isEmpty()) {
                    subparts.add(currentPart.trim());
                    currentPart = "";
                }
            } else if (command.charAt(i) == '>') {
                if (!currentPart.isEmpty()) {
                    subparts.add(currentPart.trim());
                    currentPart = "";
                }
                
                // Skip whitespace directly after '>'
                i++;
                while (i < command.length() && command.charAt(i) == ' ') {
                    i++;
                }
                // Now, accumulate the part starting with '>'
                currentPart += "> ";
                while (i < command.length() && command.charAt(i) != '|') {
                    currentPart += command.charAt(i);
                    i++;
                }
                // Decrement i here because the loop will increment it, avoiding skipping characters
                i--;
            } else {
                currentPart += command.charAt(i);
            }
            i++;
        }
        // Add the last part if it's not empty
        if (!currentPart.isEmpty()) {
            subparts.add(currentPart.trim());
        }
        return subparts;	
	}

	/**
	 * Creates a single filter from the specified subCommand
	 * 
	 * @param subCommand - the command to create a filter from
	 * @param param - the parameter which is tied to the command 
	 * @return the SequentialFilter created from the given subCommand
	 */
	private static SequentialFilter constructFilterFromSubCommand(String sc) {
		
		// Trim whitespace and split by spaces to separate command and params
        String[] parts = sc.trim().split("\\s+");

        String cmd = parts[0]; // The command keyword
        // checking if the param is there
        String param = "";
        if (parts.length > 1) {
        	param = parts[1];
        }
        
        // returning a matching filter based on the command OR the error if there aren't needed parameters for the filters.
        if (cmd.equals("pwd")) {
        	SequentialFilter pwdFilter = new PrintWorkingDirectoryFilter();
        	return pwdFilter;
		} else if (cmd.equals("ls")) {
        	SequentialFilter lsFilter = new ListFilesFilter();
        	return lsFilter;
        } else if (cmd.equals("cat")) {
        	if (param.equals("")) {
        		System.out.print(Message.REQUIRES_PARAMETER.with_parameter("cat"));
        		//err = true;
        	} else {
        		SequentialFilter catFilter = new CatFilter(param);
        		return catFilter;
		    }
        } else if (cmd.equals("cd")) {
        	if (param.equals("")) {
        		System.out.print(Message.REQUIRES_PARAMETER.with_parameter("cd"));
		    } else {
		    	SequentialFilter cdFilter = new ChangeDirectoryFilter(param);
		    	return cdFilter;
		    }
        } else if (cmd.equals("head")) {
        	if (param.equals("")) {
        		System.out.print(Message.REQUIRES_PARAMETER.with_parameter("head"));
		    } else {
		    	SequentialFilter headFilter = new HeadFilter(param);
		    	return headFilter;
		    }
        } else if (cmd.equals("tail")) {
        	if (param.equals("")) {
        		System.out.print(Message.REQUIRES_PARAMETER.with_parameter("tail"));
        	} else {
        		SequentialFilter tailFilter = new TailFilter(param);
        		return tailFilter;
        	}
        } else if (cmd.equals("grep")) {
        	if (param.equals("")) {
        		System.out.print(Message.REQUIRES_PARAMETER.with_parameter("grep"));
        	} else {
        		SequentialFilter grepFilter = new GrepFilter(param);
        		return grepFilter;
		    }
        } else if (cmd.equals("wc")) {
        	SequentialFilter wcFilter = new WordCountFilter();
        	return wcFilter;
        } else if (cmd.equals("uniq")) {
        	SequentialFilter uniqFilter = new UniqFilter();
        	return uniqFilter;
		} else if (cmd.equals(">")) {
			if (param.equals("")) {
				System.out.print(Message.REQUIRES_PARAMETER.with_parameter(">"));
			} else {
				SequentialFilter redirectFilter = new RedirectFilter(param);
				return redirectFilter;
		    }
		} else {
			//err = true;
			System.out.print(Message.COMMAND_NOT_FOUND.with_parameter(cmd + " " + param));
			return null;
		}
		return null;
	}

	/**
	 * links the given filters with the order they appear in the list
	 * 
	 * @param filters the given filters to link
	 * @return true if the link was successful, false if there were errors
	 *         encountered. Any error should be displayed by using the Message enum.
	 */
	static boolean linkFilters(List<SequentialFilter> filters) {
		
		if (filters == null || filters.isEmpty()) {
	        return false; // Return false if there are no filters to link
	    }		
		
		// check if there are any errors with the filters when linking
		for (int i = 0; i < filters.size(); i++) {
	        SequentialFilter current = filters.get(i);
	        boolean isFirst = i == 0;
	        boolean isLast = i == filters.size() - 1;

	        // Checking for commands that cannot have piped input and are not the first
	        if (!isFirst && (current instanceof PrintWorkingDirectoryFilter || current instanceof ListFilesFilter || 
	            current instanceof CatFilter || current instanceof ChangeDirectoryFilter)) {
	        	
	        	if (current instanceof PrintWorkingDirectoryFilter) {
	        		System.out.print(Message.CANNOT_HAVE_INPUT.with_parameter("pwd"));
	        	}
	        	else if (current instanceof ListFilesFilter) {
	        		System.out.print(Message.CANNOT_HAVE_INPUT.with_parameter("ls"));
	        	}
	        	else if (current instanceof CatFilter) {
	        		String p = findParameter(current);
	        		System.out.print(Message.CANNOT_HAVE_INPUT.with_parameter("cat" + " " + p));
	        	}
	        	else if (current instanceof ChangeDirectoryFilter) {
	        		String p = findParameter(current);
	        		System.out.print(Message.CANNOT_HAVE_INPUT.with_parameter("cd" + " " + p));
	        	}
	            return false;
	        }

	        // Checking for commands that must have piped input but are the first
	        if (isFirst && (current instanceof HeadFilter || current instanceof TailFilter || 
	            current instanceof GrepFilter || current instanceof WordCountFilter || 
	            current instanceof UniqFilter || current instanceof RedirectFilter)) {
	        	
	        	if (current instanceof HeadFilter) {
	        		String p = findParameter(current);
	        		System.out.print(Message.REQUIRES_INPUT.with_parameter("head" + " " + p));
	        	}
	        	else if (current instanceof TailFilter) {
	        		String p = findParameter(current);
	        		System.out.print(Message.REQUIRES_INPUT.with_parameter("tail" + " " + p));
	        	}
	        	else if (current instanceof GrepFilter) {
	        		String p = findParameter(current);
	        		System.out.print(Message.REQUIRES_INPUT.with_parameter("grep" + " " + p));
	        	}
	        	else if (current instanceof WordCountFilter) {
	        		System.out.print(Message.REQUIRES_INPUT.with_parameter("wc"));
	        	}
	        	else if (current instanceof UniqFilter) {
	        		System.out.print(Message.REQUIRES_INPUT.with_parameter("uniq"));
	        	}
	        	else if (current instanceof RedirectFilter) {
	        		String p = findParameter(current);
	        		System.out.print(Message.REQUIRES_INPUT.with_parameter(">" + " " + p));
	        	}
	            return false;
	        }

	        // Checking for commands that cannot have piped output and are not the last
	        if (!isLast && (current instanceof ChangeDirectoryFilter || current instanceof RedirectFilter)) {
	        	
	        	if (current instanceof ChangeDirectoryFilter) {
	        		String p = findParameter(current);
	        		System.out.print(Message.CANNOT_HAVE_OUTPUT.with_parameter("cd" + " " + p));
	        	}
	        	else if (current instanceof RedirectFilter) {
	        		String p = findParameter(current);
	        		System.out.print(Message.CANNOT_HAVE_OUTPUT.with_parameter(">" + " " + p));
	        	}
	            return false;
	        }
	    }

	    // Link filters if no errors
	    SequentialFilter previous = null;
	    for (SequentialFilter current : filters) {
	        if (previous != null) {
	            previous.setNextFilter(current);
	        }
	        previous = current;
	    }
	    return true;
	}
	
	/**
	 * The helper method for linkFilter method that returns filters' parameters' names from the user input
	 * to display the needed error message. 
	 * @param filter - the filter object that I have created 
	 * @return - the name of the parameter that is being passed from the user
	 */
	public static String findParameter(SequentialFilter filter) {
        
		if (filter instanceof ChangeDirectoryFilter) {
			for (String subcommand : subcommands) {
		        String[] parts = subcommand.trim().split("\\s+");
		        String cmd = parts[0]; // The command keyword
				if (cmd.equals("cd")) {
					String param = "";
			        if (parts.length > 1) {
			        	param = parts[1];
					return param;
				}
			}
		}
		
	}
		if (filter instanceof CatFilter) {
			for (String subcommand : subcommands) {
		        String[] parts = subcommand.trim().split("\\s+");
		        String cmd = parts[0]; // The command keyword
				if (cmd.equals("cat")) {
					String param = "";
			        if (parts.length > 1) {
			        	param = parts[1];
					return param;
				}
			}
		}
		
	}
		if (filter instanceof HeadFilter) {
			for (String subcommand : subcommands) {
		        String[] parts = subcommand.trim().split("\\s+");
		        String cmd = parts[0]; // The command keyword
				if (cmd.equals("head")) {
					String param = "";
			        if (parts.length > 1) {
			        	param = parts[1];
					return param;
				}
			}
		}
		
	}
		if (filter instanceof TailFilter) {
			for (String subcommand : subcommands) {
		        String[] parts = subcommand.trim().split("\\s+");
		        String cmd = parts[0]; // The command keyword
				if (cmd.equals("tail")) {
					String param = "";
			        if (parts.length > 1) {
			        	param = parts[1];
					return param;
				}
			}
		}
		
	}
		if (filter instanceof GrepFilter) {
			for (String subcommand : subcommands) {
		        String[] parts = subcommand.trim().split("\\s+");
		        String cmd = parts[0]; // The command keyword
				if (cmd.equals("grep")) {
					String param = "";
			        if (parts.length > 1) {
			        	param = parts[1];
					return param;
				}
			}
		}
		
	}
		if (filter instanceof RedirectFilter) {
			for (String subcommand : subcommands) {
		        String[] parts = subcommand.trim().split("\\s+");
		        String cmd = parts[0]; // The command keyword
				if (cmd.equals(">")) {
					String param = "";
			        if (parts.length > 1) {
			        	param = parts[1];
					return param;
				}
			}
		}
		
	}
		
		return "";
	}
}
