package cs131.pa1.filter.sequential;
import java.io.File; 
import java.util.LinkedList;

/**
 * The ListFiles filter class (the command for which is ls) extends SequentialFilter class and is supposed to implement a functionality
 * of listing files and directories in the current working directory.
 *  
 * @author Madina Nasriddinova
 *
 */

public class ListFilesFilter extends SequentialFilter {
	
	/**
	 * the method retrieves the current working directory from REPL and uses File properties in Java
	 * to go through the files and directories in the current working directory and add their names into the output. 
	 */
	@Override
	public void process() {
		if (this.output == null) {
            this.output = new LinkedList<>();
        }
		
		String directory = SequentialREPL.currentWorkingDirectory;
		File folder = new File(directory);
		File[] listOfFiles = folder.listFiles();
		
		// iterate through the listOfFiles and add the file and directory names to the output queue.
		if (listOfFiles != null) {
			for (File file : listOfFiles) {
				if (file.isFile() || file.isDirectory()) {
					output.add(file.getName());
		        }
			}
		}
	}
	
	@Override
	protected String processLine(String line) {
		return null;
	}
	
	/**
	 * since there are no error flags to be detected inside this filter class, the method always returns true.
	 */
	@Override
	public boolean isDone() {
		return true;
	}

}
