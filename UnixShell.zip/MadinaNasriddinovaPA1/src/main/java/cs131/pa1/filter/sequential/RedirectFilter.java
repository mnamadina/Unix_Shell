package cs131.pa1.filter.sequential;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;

/**
 * A filter class (the command for which is ">") that extends SequentialFilter and implements the functionality of
 * redirecting the output of preceding command and writing it to the file which name/path is passed as a parameter.
 * 
 * @author Madina Nasriddinova
 */

public class RedirectFilter extends SequentialFilter {
	
	/**
	 * boolean global variable that checks whether there is any error within the class that prevented it from being done.
	 */
	boolean errorDetected;
	
	/**
	 * the string filename that I set to the parameter's value
	 */
	private String filename;
	
	/**
	 * basic constructor
	 * @param filename - the filename/path to which the output should be written to
	 */
	public RedirectFilter(String filename) {
		this.filename = filename;
		this.input = new LinkedList<>();
        this.output = new LinkedList<>(); // even though output is not used, initializing for consistency
	}
	
	/**
	 * the process method sets the fullPath of the file and writes the contents of the input into the file.
	 */
	@Override
	public void process() {
		errorDetected = false;
	    String fullPath = SequentialREPL.currentWorkingDirectory + SequentialREPL.PATH_SEPARATOR + filename;
	    try (FileWriter writer = new FileWriter(fullPath)) {
	    	while (!input.isEmpty()) {
	    		String line = input.poll();
	            writer.write(line + System.lineSeparator());
	        }
	    } catch (IOException e) {
	    	// if the file is not there, I throw an error
	        errorDetected = true;
	        throw new RuntimeException("An error occurred while writing to file: " + filename, e);
	    }
	}
	
	@Override
	protected String processLine(String line) {
		return null;
	}
	
	/**
	 * if I have thrown an error in my process() method, my isDone() will be false, since the filter
	 * did not proceed. If my process() method did not tag the error flag to be true, I return true.
	 */
	@Override
	public boolean isDone() {
		if (errorDetected) {
			return false;
		}
		return true;
	}
	
}
