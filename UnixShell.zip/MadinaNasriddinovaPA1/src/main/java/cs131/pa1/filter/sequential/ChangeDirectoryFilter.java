package cs131.pa1.filter.sequential;
import java.io.File;

import cs131.pa1.filter.Message;

/**
 * The ChangeDirectory filter class (the command for which is cd) extends SequentialFilter class and is supposed to implement a functionality
 * of changing the working directory to the path that's specified through the String parameter.
 *  
 * @author Madina Nasriddinova
 *
 */
public class ChangeDirectoryFilter extends SequentialFilter {
	
	/**
	 * the string that 
	 */
	private String directory;
	boolean errorDetected;

	/**
	 * This constructor sets the directory to which we need to change.
	 * @param directory - the directory path to which we need to change
	 */
	public ChangeDirectoryFilter(String directory) {
        this.directory = directory;
    }
	
	/**
	 * This method evaluates the path that we need to change the current working directory to.
	 * If the path given is not found, the filter throws an error flag.
	 */
	@Override
	public void process() {
		errorDetected = false;
	    File newDir;
	    if (directory.equals(".")) {
	        // No change required
	        return;
	    } else if (directory.equals("..")) {
	        // Go up to the parent directory
	        newDir = new File(SequentialREPL.currentWorkingDirectory).getParentFile();
	        if (newDir == null) {
	            // If we are at the root directory, nothing happens
	            return;
	        }
	    } else {
	        // Handle relative and absolute paths
	        newDir = new File(SequentialREPL.currentWorkingDirectory, directory);
	        if (!newDir.exists()) {
	            // Try as an absolute path if not found relative to the current directory
	            newDir = new File(directory);
	        }
	    }
	    
	    // Check if the directory exists and is indeed a directory
	    if (newDir.exists() && newDir.isDirectory()) {
	        SequentialREPL.currentWorkingDirectory = newDir.getAbsolutePath();
	    } else {
	        System.out.print(Message.DIRECTORY_NOT_FOUND.with_parameter("cd" + " " + directory));
	    	errorDetected = true;
	    }
	}
	
	@Override
	protected String processLine(String line) {
		// since cd cannot have piped input, there is no processLine
		return null;
	}
	
	/**
	 * if I have thrown an error in my process() method, my isDone() will be false, since the filter
	 * did not proceed. If my process() method did not tag the error flag to be true, I return true.
	 */
	@Override
	public boolean isDone() {
		if (errorDetected) {
			return false;
		}
		return true;
	}
}
