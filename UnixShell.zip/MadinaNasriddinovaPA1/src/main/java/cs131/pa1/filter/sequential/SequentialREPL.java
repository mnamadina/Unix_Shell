package cs131.pa1.filter.sequential;
import java.util.List;
import java.util.Scanner;
import cs131.pa1.filter.Message;

/**
 * The main implementation of the REPL (read-eval-print-loop). It reads
 * commands from the user, parses them, executes them and displays the result.
 * 
 * @author Madina Nasriddinova
 *
 */
public class SequentialREPL {
	
	/**
	 * The path of the current working directory
	 */
	public static String currentWorkingDirectory;
	/**
	 * The path for the OS that runs the code -- used in pwd/cd/etc. 
	 */
	public static final String PATH_SEPARATOR = System.getProperty("file.separator");

	/**
	 * The main method that will execute the REPL loop
	 * 
	 * @param args not used
	 */
	public static void main(String[] args) {
		currentWorkingDirectory = System.getProperty("user.dir");
		
		Scanner scanner = new Scanner(System.in);
		System.out.print(Message.WELCOME);
		
        while (true) {
        	System.out.print(Message.NEWCOMMAND);
            String command = scanner.nextLine();
        
            if (command.equals("exit")) {
                System.out.print(Message.GOODBYE);
                break;
            }
            
            // create filters from the command
            List<SequentialFilter> filters = SequentialCommandBuilder.createFiltersFromCommand(command);            
            // if linking the filters has been successful
            if (SequentialCommandBuilder.linkFilters(filters)) {
                    for (SequentialFilter filter : filters) {
                    	// and the filter/s are not null, I will process them 
                    	if (filters.size() != 0 && filter != null) {
                    		filter.process();
                    		// if there is an error within the filter class detected, I will break the processing
                    		if (!filter.isDone()) { 
                    	        break;
                    		}
                    	}
                    }	
                    // for printing the output, I only need the last filter's output for print-out
                    if (filters.size() != 0) {
                    	SequentialFilter lastFilter = filters.get(filters.size() - 1);
                        if (lastFilter.output != null && lastFilter != null) {
                        	 while (lastFilter.output.size() != 0) {
                                 System.out.println(lastFilter.output.poll());
                             }
                        }
                    
                    }      
            }
        }
        scanner.close();
    }
}
