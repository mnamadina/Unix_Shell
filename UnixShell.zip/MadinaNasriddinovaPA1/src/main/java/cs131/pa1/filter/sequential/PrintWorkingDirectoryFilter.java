package cs131.pa1.filter.sequential;
import java.util.LinkedList; 

/**
 * A filter class that extends SequentialFilter and implements the functionality of
 * printing a current working directory (the command is pwd).
 * @author Madina Nasriddinova
 *
 */

public class PrintWorkingDirectoryFilter extends SequentialFilter {
	
	/**
	 * adds the current working directory to the output (that will be printed in the SequentialREPL class)
	 */
	@Override
	public void process() {
		if (this.output == null) {
			this.output = new LinkedList<>();
		}
		this.output.add(SequentialREPL.currentWorkingDirectory);
	}
	
	@Override
	protected String processLine(String line) {		
		return null;
	}
	
	/**
	 * I am overriding the initial method since this filter class should always be returning true, as there are
	 * no internal errors happening in the class (all errors associated with pwd would appear outside of the class)
	 */
	@Override
	public boolean isDone() {
		return true;
	}
	
}
