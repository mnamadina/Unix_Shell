package cs131.pa1.filter.sequential;
import java.util.LinkedList;

/**
 * This grep filter class extends SequentialFilter class and performs the basic functionality of
 * sending the lines that contain the 'query' word/phrase (that's passed as a parameter to the class)
 * to the output queue.
 * @author Madina Nasriddinova

 *
 */
public class GrepFilter extends SequentialFilter {
	
	/**
	 * the string query that will take on the parameter query passed on to the constructor
	 */
	private String query;
	
	/**
	 * A basic constructor that sets the string parameter to the query and creates an output queue
	 * @param query - the parameter that sends the query that we are going to be checking for in the input lines
	 */
	public GrepFilter(String query) {
		this.query = query;
		if (this.output == null) {
			this.output = new LinkedList<>();
		}
	}
	
	/**
	 * Overriding the original processLine() from the SF filter class to check whether the line from the 
	 * input contains the query. If it does, return line to be added to the output.
	 * @param line - the line from the input which we check for query existence
	 */
	@Override
	protected String processLine(String line) {
		if (line.contains(query)) {
			return line;
		}
		return null;
	}

	/**
	 * since there are no error flags to be detected inside this filter class, the method always returns true.
	 */
	@Override
	public boolean isDone() {
		return true;
	}
}	
