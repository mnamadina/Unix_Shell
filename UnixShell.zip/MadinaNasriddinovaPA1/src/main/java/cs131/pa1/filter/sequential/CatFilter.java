package cs131.pa1.filter.sequential;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;

import cs131.pa1.filter.Message;

/**
 * This filter class extends SequentialFilter class and writes the file's output into the pipe or stdout.
 * The filename is passed in a string format as a parameter.
 * 
 * @author Madina Nasriddinova
 *
 */
public class CatFilter extends SequentialFilter {
	
	/**
	 * the string will denote a filename which content we will be writing into pipe/stdout.
	 */
	private String file;
	/**
	 * this boolean will be used later for our method isDone() to check whether there has been any
	 * error associated within the class, and whether the piping should continue happening.
	 */
	boolean errorDetected;
	
	/**
	 * This constructor sets the file (name) to be the one that's passed as a parameter
	 * @param file - the name of the file which contents we will be writing
	 */
	public CatFilter(String file) {
        this.file = file;
    }
	
	/**
	 * The method process() overrides the original one from SF. It creates the path for the file and reads it from the provided path
	 * as well as sending each line from the file to the output queue. If the file was not found, I throw an error and print out the message
	 * error that the file was not found in the cat filter. I also then tag an error flag that is used in my
	 * isDone() method to signify to the following subcommands that there has been an error.
	 */
	@Override
	public void process() {
		if (this.output == null) {
            this.output = new LinkedList<>();
        }
		errorDetected = false;
		String path = SequentialREPL.currentWorkingDirectory + SequentialREPL.PATH_SEPARATOR + this.file;		
		    
        // this will read the file and close it after reading
        try (BufferedReader reader = new BufferedReader(new FileReader(path))) {
        	String line;
            // iterate through the file and add each line to the output
            while ((line = reader.readLine()) != null) {
            	this.output.add(line);     
            }
             // if there is an error, 
            } catch (IOException e) {
            	errorDetected = true;
                System.out.print(Message.FILE_NOT_FOUND.with_parameter("cat" + " " + file));
            }  
    }
	
	@Override
	protected String processLine(String line) {
        // This method is not used for CatFilter, as file reading is handled differently.
		return null;
	}
	
	/**
	 * if I have thrown an error in my process() method, my isDone() will be false, since the filter
	 * did not proceed. If the cat filter read and wrote the contents of the file all good, then I return true.
	 */
	@Override 
	public boolean isDone() {
		if (errorDetected) {
			return false;
		}
		return true;
	}
	
}
